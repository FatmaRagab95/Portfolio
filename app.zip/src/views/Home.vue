<template>
  <div class="home  overflow-y-auto fill-height box txtBox--text elevation-12">
    <v-container class="fill-height px-6">
      <v-row class="fill-height" align="center" justify="center">
        <v-col cols="12" class="text-center">
          <h1 class="main-heading">Johnny Doe</h1>
          <p class="mt-3">Front-end Developer</p>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  components: {},
}
</script>
